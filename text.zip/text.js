function myArr(X) {
  Object.defineProperty(this, 'length', {
    value: 0,
    writable: true,
    enumerable: false,
    configurable: true,
  })
  this.length = arguments.length
  for (let i = 0; i < this.length; i++) {
    this[i] = arguments[i]
  }
  myArr.prototype.pushh = function (element) {
    let index = this.length
    this.length++
    this[index] = element
  }
  myArr.prototype.gop = function (element) {
    let index = this.length - 1
    delete this[index]
    this.length--
  }
  myArr.prototype.revers = function (element) {
    var ars = []
    for (let i = this.length - 1; i >= 0; i--) {
      ars.push(this[i])
    }
    return ars['0']
  }
  myArr.prototype.zero = function () {
    var a = this[0]
    return a
  }
}
var arr = new myArr('alpha', 'beta', 'gamma')
arr.pushh('zeta')
// arr.gop()
console.log('arr:', arr.zero())
