function myArr(X) {
  Object.defineProperty(this, 'length', {
    value: 0,
    writable: true,
    enumerable: false,
    configurable: true,
  })
  this.length = arguments.length
  for (let i = 0; i < this.length; i++) {
    this[i] = arguments[i]
  }
  myArr.prototype.pushh = function (element) {
    let index = this.length
    this.length++
    this[index] = element
  }
  myArr.prototype.gop = function (element) {
    let index = this.length - 1
    delete this[index]
    this.length--
  }
}
var arr = new myArr('alpha', 'beta', 'gamma')
arr.pushh('zeta')
arr.gop()
console.log('arr:', Object.values(arr))
